<?php

namespace App\Admin\Controllers;

use App\Models\MyMusic;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class MyMusicController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'MyMusic';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */

/*Schema::create('my_music', function (Blueprint $table) {
    $table->id();
    $table->String("artist_name");
    $table->String("album_name");
    $table->date("released_on");
    $table->String("music_name");
    $table->timestamps();
});*/
    protected function grid()
    {
        $grid = new Grid(new MyMusic());
        $grid->column("id","ID");
        $grid->column("artist_name","Artist Name");
        $grid->column("music_name","music_name");
        $grid->column("artist_name","Album Name");
        $grid->column("released_on","released_on");

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(MyMusic::findOrFail($id));



        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new MyMusic());
        $form->text("artist_name","Artist Name");
        $form->text("music_name","music_name");
        $form->text("artist_name","Album Name");
        $form->date("released_on","released_on");


        return $form;
    }
}

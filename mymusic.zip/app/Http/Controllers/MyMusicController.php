<?php

namespace App\Http\Controllers;

use App\Models\MyMusic;
use http\Env\Response;
use Illuminate\Http\Request;

class MyMusicController extends Controller
{
    public function index(){
        $info=MyMusic::get();
        return json_decode($info);
    }

    public function submitinfo(Request $request){
        $info=new MyMusic();
        $info->artist_name=$request->post("artist_name");
        $info->album_name=$request->post("album_name");
        $info->released_on=$request->post("released_on");
        $info->music_name=$request->post("music_name");

            if ($info->save()){
                return response()->json([
                    "code"=>200,
                    "msg"=>"success"
                ]);
            }else{
                return response()->json([
                    "code"=>403,
                    "msg"=>"failed"
                ]);
            }
    }

    public function update(Request $request , $id){

        $info=MyMusic::find($id);
        if(!$info)  {
            return response()->json([
               "code"=>404,
               "msg"=>"page not found"
            ]);
        }

        $info->artist_name=$request->post("artist_name");
        $info->album_name=$request->post("album_name");
        $info->released_on=$request->post("released_on");
        $info->music_name=$request->post("music_name");

        if ($info->save()){
            return response()->json([
                "code"=>200,
                "msg"=>"success"
            ]);
        }else{
            return response()->json([
                "code"=>403,
                "msg"=>"failed"
            ]);
        }
    }
}
